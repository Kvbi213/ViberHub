#!/usr/bin/env bash
set -e

echo "================================================================"
echo "[*] INFO :: VibeHub Bridge CLI Installer (Linux/macOS)"
echo "================================================================"

if ! command -v node >/dev/null 2>&1; then
    echo "[!] ALERT :: Node.js is required. Install Node.js LTS from https://nodejs.org"
    exit 1
fi

INSTALL_DIR="$HOME/.vibehub/bin"
mkdir -p "$INSTALL_DIR"

BASE_URL="https://viberhub-8842f.web.app"
curl -fsSL "$BASE_URL/vibehub-cli-bundle.cjs" -o "$INSTALL_DIR/vibehub-cli-bundle.cjs"

cat << 'EOF' > "$INSTALL_DIR/vibehub"
#!/usr/bin/env bash
exec node "$HOME/.vibehub/bin/vibehub-cli-bundle.cjs" "$@"
EOF
chmod +x "$INSTALL_DIR/vibehub"

if [[ ":$PATH:" != *":$INSTALL_DIR:"* ]]; then
    PROFILE_FILE="$HOME/.bashrc"
    [[ "$SHELL" == *"zsh"* ]] && PROFILE_FILE="$HOME/.zshrc"
    echo "export PATH=\"\$HOME/.vibehub/bin:\$PATH\"" >> "$PROFILE_FILE"
    echo "[+] SUCCESS :: Added $INSTALL_DIR to $PROFILE_FILE"
fi

export PATH="$INSTALL_DIR:$PATH"
echo "================================================================"
echo "[+] SUCCESS :: VibeHub CLI installed successfully!"
echo "[*] INFO :: Run: vibehub pair [CODE]"
echo "================================================================"
node "$INSTALL_DIR/vibehub-cli-bundle.cjs" status
