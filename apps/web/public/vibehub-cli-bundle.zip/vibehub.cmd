@echo off
node "%~dp0vibehub-cli-bundle.cjs" %*
