@echo off
echo ================================================================
echo [*] INFO :: Instalator VibeHub Bridge CLI dla Windows
echo ================================================================
set "TARGET_DIR=%USERPROFILE%\.vibehub\bin"
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
copy /y "%~dp0vibehub-cli-bundle.cjs" "%TARGET_DIR%\" >nul
copy /y "%~dp0vibehub.cmd" "%TARGET_DIR%\" >nul
copy /y "%~dp0vibehub.ps1" "%TARGET_DIR%\" >nul

echo [+] SUCCESS :: Skopiowano pliki CLI do: %TARGET_DIR%
echo [*] INFO :: Rejestracja w zmiennej srodowiskowej PATH...
powershell -Command "[Environment]::SetEnvironmentVariable('PATH', [Environment]::GetEnvironmentVariable('PATH', 'User') + ';%TARGET_DIR%', 'User')" 2>nul

echo ================================================================
echo [+] SUCCESS :: VibeHub CLI zostal pomyslnie zainstalowany!
echo [*] INFO :: Otworz nowe okno terminala PowerShell i wpisz:
echo     vibehub pair [KOD]
echo ================================================================
pause
